package ru.aiphotostudio.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

private val Bg = Color(0xFF101116)
private val Panel = Color(0xFF1B1D25)
private val Accent = Color(0xFF9B8CFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudioScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen() {
    var photo by remember { mutableStateOf<Uri?>(null) }
    var prompt by remember { mutableStateOf("") }
    var selectedTool by remember { mutableStateOf("Одежда") }
    var notice by remember { mutableStateOf("Выбери фотографию, чтобы начать") }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            photo = uri
            notice = "Фото загружено. Можно подготовить описание изменений."
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = Panel
        )
    ) {
        Scaffold(containerColor = Bg) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("AI PHOTO STUDIO", color = Accent, style = MaterialTheme.typography.labelLarge)
                        Text("Твоя AI-фотостудия", color = Color.White,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold)
                    }
                    Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = Accent,
                        modifier = Modifier.size(34.dp))
                }

                Surface(color = Panel, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(310.dp)
                            .padding(10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (photo == null) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Rounded.AddPhotoAlternate, null, tint = Accent, modifier = Modifier.size(54.dp))
                                Spacer(Modifier.height(12.dp))
                                Text("Здесь появится фотография", color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text("Загрузи снимок человека", color = Color.LightGray)
                                Spacer(Modifier.height(16.dp))
                                Button(onClick = { picker.launch("image/*") }) {
                                    Icon(Icons.Rounded.PhotoLibrary, null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Выбрать фото")
                                }
                            }
                        } else {
                            AsyncImage(model = photo, contentDescription = "Выбранная фотография",
                                modifier = Modifier.fillMaxSize())
                        }
                    }
                }

                if (photo != null) {
                    OutlinedButton(
                        onClick = { picker.launch("image/*") },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.ChangeCircle, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Выбрать другую фотографию")
                    }
                }

                Text("Что изменить?", color = Color.White, fontWeight = FontWeight.Bold)
                val tools = listOf(
                    "Одежда" to Icons.Rounded.Checkroom,
                    "Поза" to Icons.Rounded.AccessibilityNew,
                    "Фон" to Icons.Rounded.Landscape,
                    "Внешность" to Icons.Rounded.Face,
                    "Другой человек" to Icons.Rounded.Person
                )
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    tools.chunked(2).forEach { rowTools ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            rowTools.forEach { item ->
                                FilterChip(
                                    selected = selectedTool == item.first,
                                    onClick = { selectedTool = item.first },
                                    label = { Text(item.first) },
                                    leadingIcon = { Icon(item.second, null, modifier = Modifier.size(18.dp)) }
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Опиши желаемый результат") },
                    placeholder = { Text("Например: красное вечернее платье, фон — Париж ночью") },
                    minLines = 3,
                    shape = RoundedCornerShape(16.dp)
                )

                Button(
                    onClick = {
                        notice = if (photo == null) "Сначала выбери фотографию"
                        else "Макет готов: AI-движок ещё не подключён. Следующий этап — интеграция бесплатной модели."
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Rounded.AutoFixHigh, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Создать изображение")
                }

                Surface(color = Panel, shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Info, null, tint = Accent)
                        Spacer(Modifier.width(10.dp))
                        Text(notice, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                    }
                }

                Text(
                    "Версия 0.1 • Бесплатная основа • Фото выбирается с устройства",
                    color = Color.Gray,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}
